#ifndef WELCOME_H
#define WELCOME_H

#include <QDialog>

namespace Ui {
class Welcome;
}

class Welcome : public QDialog
{
    Q_OBJECT

public:
    explicit Welcome(QWidget *parent = nullptr);
    ~Welcome();

private slots:
    void on_pushButton_3_clicked();

    void on_StartGame_clicked();

    void on_HIghScores_clicked();

private:
    Ui::Welcome *ui;
};

#endif // WELCOME_H
