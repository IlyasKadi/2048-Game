#include "highscores.h"
#include "ui_highscores.h"
#include "numsgame.h"
#include "ui_numsgame.h"




HighScores::HighScores(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::HighScores)
{
    ui->setupUi(this);
    Scorelistmodel = new QStandardItemModel;
       loadscores();
}

HighScores::~HighScores()
{
    delete ui;
}

void HighScores::loadscores()
{
    NumsGame newgame;

    newgame.db =QSqlDatabase::addDatabase("QSQLITE");
    newgame.db.setDatabaseName("/home/ilyas/Desktop/scores_.sqlite");
    newgame.db.open();

    QSqlQuery scores("SELECT * from score  order by score desc",newgame.db);

   //Load data from DB to each task_List
    while(scores.next())
        newgame.scoreslisttoload.append("        "+scores.value(0).toString() + "                          " + scores.value(1).toString()+"");

    for(auto e :newgame.scoreslisttoload)
    {
        QString path{""};
        QIcon icon(path);
        ui->listView->setModel(Scorelistmodel);
        Scorelistmodel->appendRow(new QStandardItem(QIcon(icon),e));
    }
}
