#ifndef NUMSGAME_H
#define NUMSGAME_H

#include <QDialog>
#include <QGridLayout>
#include <QLabel>
#include <QVBoxLayout>
#include <utility>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class NumsGame; }
QT_END_NAMESPACE

class NumsGame : public QDialog
{
    Q_OBJECT

protected:
    void keyPressEvent(QKeyEvent *event);

public:
     NumsGame(QWidget *parent = nullptr);
       Ui::NumsGame *ui;

    QSqlDatabase db;
    QStringList scoreslisttoload;
    QStringList scoreslist;
    std::vector<int> scoreslistnum;
    QStringList scorenames;
    void setdatabase(QString nickname,  int score);
    QVBoxLayout *lablayout = nullptr;
    QGridLayout *boardLayout=nullptr;
    void setMainBorder();
    void setinitialpos();
    QVector<QVector<int>> numsMatrix;
    QVector< QVector<int>> oladboard;
    QLabel * settile(int numberintile);
    std::pair<int, int> formrandpos();
    int score=0;
    int bscore=0;
    void move_or_die();
    void moveUp();
    void moveDown();
    void moveLeft();
    void moveRight();
    void putOnnums();
    void reset();
    void gameOver();
    void winner();
    void ScoreAddedSayHi(int scoreadded);

        ~NumsGame();

private slots:
    void on_resetbutton_clicked();

    void on_Tryagain_clicked();

    void on_Quit_clicked();

    void on_newGame_clicked();

    void on_submit_clicked();



};
#endif // NUMSGAME_H
