#include "numsgame.h"
#include "ui_numsgame.h"
#include <QGraphicsDropShadowEffect>
#include <QKeyEvent>
#include <QTimer>
#include <vector>
#include <QMessageBox>


NumsGame::NumsGame(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::NumsGame)
{
    ui->setupUi(this);
    this->setFixedSize(this->geometry().width(),this->geometry().height());

    //set up game
    numsMatrix.resize(4);
    for (int i = 0; i < 4; i++)
        numsMatrix[i].resize(4);
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4;j++)
            numsMatrix[i][j]=0;


    ui->gameoverlabel->hide();
    ui->winner->hide();
    ui->Tryagain->hide();
    ui->newGame->hide();
    ui->Quit->hide();
    ui->lastScore->hide();
    ui->youreScore->hide();
    ui->nicknamelabel->hide();
    ui->Nickname->hide();
    ui->alreadyExist->hide();
    ui->submit->hide();
    setMainBorder();
   // putOnnums();

    db =QSqlDatabase::addDatabase("QSQLITE");
     db.setDatabaseName("/home/ilyas/Desktop/scores_.sqlite");
     db.open();



     QSqlQuery scores("SELECT * from score ",db);



    //Load data from DB to each task_List
     while(scores.next())
         scoreslist.append(scores.value(1).toString()+"");


   for(QString e: scoreslist)
        scoreslistnum.push_back(e.toInt());

      sort(scoreslistnum.begin(), scoreslistnum.end());
      ui->BEST_SCORE_N->setText(QString::number(scoreslistnum[scoreslistnum.size()-1]));
      ui->BEST_SCORE_N->text().toInt();






}

NumsGame::~NumsGame()
{
    delete ui;
}


//Setting up base view
void NumsGame::setMainBorder()
{

for (int i = 0; i < 4; ++i) {
   for (int j = 0; j < 4; ++j) {

        QLabel *label = new QLabel();

         label->setStyleSheet("background: rgb(205,192,180);" "border-radius: 10px;" "color: rgb(119,110,101);" );

         label->setAlignment(Qt::AlignCenter);
         ui->gridboard->addWidget(label,i,j);

   }

}
 setinitialpos();
}

//Design of tile based on each number
QLabel * NumsGame:: settile(int numberintile)
{
       QString labelNum = QString::number(numberintile);
       QLabel *tile = new QLabel(labelNum);
       tile->setAlignment(Qt::AlignCenter);


        switch (numberintile) {
        case 2: {
            tile->setStyleSheet("background: rgb(238,228,218);" "color: rgb(119,110,101);" "font: bold; border-radius: 10px; font: 22pt;");
            break;
        }
        case 4: {
           tile->setStyleSheet("background: rgb(237,224,200);" "color: rgb(119,110,101);" "font: bold; border-radius: 10px; font: 22pt;");
            break;
        }
        case 8: {
           tile->setStyleSheet("background: rgb(242,177,121);" "color: rgb(255,255,255);" "font: bold; border-radius: 10px; font: 22pt;");
            break;
        }
        case 16: {
            tile->setStyleSheet("background: rgb(245,150,100);" "color: rgb(255,255,255);" "font: bold; border-radius: 10px; font: 22pt;");
            break;
        }
        case 32: {
            tile->setStyleSheet("background: rgb(245,125,95);" "color: rgb(255,255,255);" "font: bold; border-radius: 10px; font: 22pt;");
            break;
        }
        case 64: {
            tile->setStyleSheet("background: rgb(245,95,60);" "color: rgb(255,255,255);" "font: bold; border-radius: 10px; font: 22pt;");
            break;
        }
        case 128: {

            tile->setStyleSheet("background: rgb(237,207,114);" "color: rgb(255,255,255);" "font: bold;" "border-radius: 10px; font: 22pt;");
            break;
        }
        case 256: {
            QGraphicsDropShadowEffect *dse = new QGraphicsDropShadowEffect();
            dse->setColor(Qt::yellow);
            dse->setBlurRadius(20);
            dse->setOffset(-1);
           // tile->setGraphicsEffect(dse);
            tile->setStyleSheet("background: rgb(237,204,97);" "color: rgb(255,255,255);" "font: bold; border-radius: 10px; font: 22pt;");
            break;
        }
        case 512: {
            QGraphicsDropShadowEffect *dse = new QGraphicsDropShadowEffect();
            dse->setColor(Qt::yellow);
            dse->setBlurRadius(30);
            dse->setOffset(-1);
           // tile->setGraphicsEffect(dse);
            tile->setStyleSheet("background: rgb(237,204,97);" "color: rgb(255,255,255);" "font: bold; border-radius: 10px; font: 22pt;");
            break;
        }
        case 1024: {
            QGraphicsDropShadowEffect *dse = new QGraphicsDropShadowEffect();
            dse->setColor(Qt::yellow);
            dse->setBlurRadius(40);
            dse->setOffset(-1);
           // tile->setGraphicsEffect(dse);
            tile->setStyleSheet("background: rgb(237,204,97);" "color: rgb(255,255,255);" "font: bold; border-radius: 10px; font: 22pt;");
            break;
        }
        case 2048: {
            QGraphicsDropShadowEffect *dse = new QGraphicsDropShadowEffect();
            dse->setColor(Qt::yellow);
            dse->setBlurRadius(50);
            dse->setOffset(-1);
            //tile->setGraphicsEffect(dse);
            tile->setStyleSheet("background: rgb(237,204,97);"  "color: rgb(255,255,255); font: bold;" "border-radius: 10px; font: 22pt;");
            break;
        }
        default: {
            tile = new QLabel();
            tile->setStyleSheet("background: rgb(205,192,180);" "border-radius: 10px;" "color: rgb(119,110,101);");
            break;
        }
}
return tile;
}

//Forming a random position
std::pair<int, int> NumsGame::formrandpos()
{
    int randi = rand() % 4;
    int randj = rand() % 4;
     return std::make_pair(randj, randi);
}

//Setting up two first tiles to start with
void NumsGame::setinitialpos()
{
        auto [rndi,rndj]=formrandpos();
        auto [rndi_,rndj_]=formrandpos();


      numsMatrix[rndi][rndj]=2;
      numsMatrix[rndi_][rndj_]=2;

     ui->gridboard->addWidget(settile(2),rndi,rndi);
     ui->gridboard->addWidget(settile(2),rndi_,rndj_);
}
void NumsGame::keyPressEvent(QKeyEvent *event)
{
    switch (event->key())
    {
          case Qt::Key_Up:
         {
            moveUp();
            ui->resetbutton->setEnabled(1);
            break;
         }
         case Qt::Key_Left:
        {
            moveLeft();
            ui->resetbutton->setEnabled(1);
            break;
        }
         case Qt::Key_Right:
        {
            moveRight();
            ui->resetbutton->setEnabled(1);
            break;
        }
         case Qt::Key_Down:
        {
            moveDown();
            ui->resetbutton->setEnabled(1);
            break;
        }
   }
}



void NumsGame::putOnnums()
{

    for(int i=0; i<4 ;i++)
    {
        for(int j=0; j<4 ;j++)
        {
            ui->gridboard->addWidget(settile(0),i,j);
        }
    }

    for(int i=0; i<4 ;i++)
    {
        for(int j=0; j<4 ;j++)
        {
            if(numsMatrix[i][j]!=0)
            ui->gridboard->addWidget(settile(numsMatrix[i][j]),i,j);
        }
    }
}

void NumsGame::moveUp()
{
    oladboard=numsMatrix;


    //this is a space remover phase

    for (int j = 0; j < 4; j++)
    {
        for (int i = 1; i < 4; i++)
        {
                 if (numsMatrix[i][j] != 0)
                {
                     for(int k=0;k<i;k++)
                     {
                       if (numsMatrix[k][j] == 0)
                      {
                        numsMatrix[k][j]=numsMatrix[i][j];
                        numsMatrix[i][j]=0;
                      }
                  }
             }
        }
    }

 //this is the sum phase (and so on concerning other dorections)
    for (int j = 0; j < 4; j++)
      {
      for (int i = 1; i < 4; i++)
        {
         if (numsMatrix[i][j] != 0)
          {
          if(numsMatrix[i-1][j] == numsMatrix[i][j] )
           {
             numsMatrix[i-1][j]=numsMatrix[i][j]*2;
             ScoreAddedSayHi( numsMatrix[i-1][j]);
             score+=numsMatrix[i-1][j];
             numsMatrix[i][j]=0;
           }
         }
       }
     }
    //this is another space remover phase (and the same for other dorections)

    for (int j = 0; j < 4; j++)
      {
      for (int i = 1; i < 4; i++)
        {
        if (numsMatrix[i][j] != 0)
         {
         for(int k=0;k<i;k++)
           {
           if (numsMatrix[k][j] == 0)
            {
               numsMatrix[k][j]=numsMatrix[i][j];
               numsMatrix[i][j]=0;
            }
           }
         }
        }
      }
      putOnnums();
      move_or_die();
}


void NumsGame::moveDown()
{
    oladboard=numsMatrix;

    for(int j=0;j<4;j++)
    {
        for(int i=2;i>=0;i--)
        {
            if(numsMatrix[i][j]!=0)
            {
                for(int k=3;k>i;k--)
                {
                    if(numsMatrix[k][j]==0)
                    {
                        numsMatrix[k][j]=numsMatrix[i][j];
                        numsMatrix[i][j]=0;
                    }
                }
            }
        }
    }

    for(int j=0;j<4;j++)
    {
        for(int i=2;i>=0;i--)
        {
            if(numsMatrix[i][j]!=0)
            {
               if(numsMatrix[i+1][j]==numsMatrix[i][j])
                {
                   numsMatrix[i+1][j]=numsMatrix[i][j]*2;
                   ScoreAddedSayHi(numsMatrix[i+1][j]);
                   score+=numsMatrix[i+1][j];
                   numsMatrix[i][j]=0;
                }
           }
        }
     }

    for(int j=0;j<4;j++)
    {
        for(int i=2;i>=0;i--)
        {
            if(numsMatrix[i][j]!=0)
            {
                for(int k=3;k>i;k--)
                {
                    if(numsMatrix[k][j]==0)
                    {
                        numsMatrix[k][j]=numsMatrix[i][j];
                        numsMatrix[i][j]=0;
                    }
                }
            }
        }
    }
    putOnnums();
    move_or_die();
}

void NumsGame::moveRight()
{
   oladboard=numsMatrix;
    for(int i=0;i<4;i++)
    {
        for(int j=2;j>=0;j--)
        {
            if(numsMatrix[i][j]!=0)
            {
               for(int k=3;k>j;k--)
                {
                    if(numsMatrix[i][k]==0)
                    {
                        numsMatrix[i][k]=numsMatrix[i][j];
                        numsMatrix[i][j]=0;
                    }
                }
            }
        }
    }

    for(int i=0;i<4;i++)
    {
        for(int j=2;j>=0;j--)
        {
            if(numsMatrix[i][j]!=0)
            {
               if(numsMatrix[i][j+1]==numsMatrix[i][j] )
               {
                   numsMatrix[i][j+1]=numsMatrix[i][j]*2;
                   ScoreAddedSayHi( numsMatrix[i][j+1]);
                   score+=numsMatrix[i][j+1];
                   numsMatrix[i][j]=0;
               }
            }
        }
    }

    for(int i=0;i<4;i++)
    {
        for(int j=2;j>=0;j--)
        {
            if(numsMatrix[i][j]!=0)
            {
                for(int k=3;k>j;k--)
                {
                    if(numsMatrix[i][k]==0)
                    {
                        numsMatrix[i][k]=numsMatrix[i][j];
                        numsMatrix[i][j]=0;
                    }
                }
            }
        }
    }
    putOnnums();
    move_or_die();
}

void NumsGame::moveLeft()
{
    oladboard=numsMatrix;

    for(int i=0;i<4;i++)
    {
        for(int j=1;j<4;j++)
        {
            if(numsMatrix[i][j]!=0)
            {
                for(int k=0;k<j;k++)
                {
                    if(numsMatrix[i][k]==0)
                    {
                        numsMatrix[i][k]=numsMatrix[i][j];
                        numsMatrix[i][j]=0;
                    }
                }
            }
        }
    }

    for(int i=0;i<4;i++)
    {
        for(int j=1;j<4;j++)
        {
            if(numsMatrix[i][j]!=0)
            {
                if(numsMatrix[i][j-1]==numsMatrix[i][j] )
                {
                    numsMatrix[i][j-1]=numsMatrix[i][j]*2;
                    ScoreAddedSayHi( numsMatrix[i][j-1]);
                    score+=numsMatrix[i][j-1];
                    numsMatrix[i][j]=0;
                }
            }
        }
    }

    for(int i=0;i<4;i++)
    {
        for(int j=1;j<4;j++)
        {
            if(numsMatrix[i][j]==0)
            {
                for(int k=0;k<j;k++)
                {
                    if(numsMatrix[i][k]==0)
                    {
                        numsMatrix[i][k]=numsMatrix[i][j];
                        numsMatrix[i][j]=0;
                    }
                }
            }
        }
    }
    putOnnums();
    move_or_die();
}



void NumsGame::gameOver()
{
    ui->Tryagain->setEnabled(1);
    ui->gameoverlabel->show();
    ui->Tryagain->show();
    ui->lastScore->setText(QString::number(score));
    ui->lastScore->show();
    ui->youreScore->show();
    ui->nicknamelabel->show();
    ui->Nickname->show();
    ui->submit->show();
}


void NumsGame::winner()
{
    ui->newGame->setEnabled(1);
    ui->Quit->setEnabled(1);
    ui->Quit->show();
    ui->winner->show();
    ui->newGame->show();
    ui->Quit->show();
    ui->lastScore->setText(QString::number(score));
    ui->lastScore->show();
    ui->youreScore->show();
    ui->nicknamelabel->show();
    ui->Nickname->show();
    ui->submit->show();
}
void NumsGame:: move_or_die()
{
    int c=0;
    //No_Tile_Left loop check
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4;j++)
        {
            if( numsMatrix[i][j]==0)
           {
              c++;
           }
        }
    }

    //No_Sum_possible_ loop check by cols
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 3;j++)
        {
            if( numsMatrix[i][j]== numsMatrix[i][j+1])
           {
              c++;
           }
        }
    }
    //No_Sum_possible_ loop check by rows
    for (int j = 0; j < 4; j++)
    {
        for (int i = 0; i < 3;i++)
        {
            if( numsMatrix[i][j]== numsMatrix[i+1][j])
           {
              c++;
           }
        }
    }


    //Win loop check
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4;j++)
        {
            if( numsMatrix[i][j]==2048)
           {
             winner();
           }
        }
    }

    //condition that check if next move is possible :
    if( oladboard!=numsMatrix) //movement possible
    {
       //updating score:
        ui->Score_N->setText(QString::number(score));
        if(bscore<score)
        {
            bscore=score;
            ui->BEST_SCORE_N->setText(QString::number(score));
        }

        //making a rand free position
        std:: pair<int, int> randpos =formrandpos();
        do {
            randpos =formrandpos();
        } while (numsMatrix[randpos.first][randpos.second] != 0);


        //to add a new tile in it:
        numsMatrix[randpos.first][randpos.second]=2 ;
        ui->gridboard->addWidget(settile(2),randpos.first,randpos.second);
    }
    else if(oladboard==numsMatrix && c==0) // movement impossible you're dead +_+
    {
        gameOver();
    }
    // otherwise do nothing (won't add a tile)
}


// a small label that shows up everytime you add up two same tiles
void NumsGame::ScoreAddedSayHi(int i)
{
    ui->scoreadded->setText("+"+QString::number(i));
    ui->scoreadded->show();
    QTimer::singleShot(500, ui->scoreadded, &QLabel::hide);
}

void NumsGame::reset()
{
   score=0;
   for(int i=0; i<4 ;i++)
   {
       for(int j=0; j<4 ;j++)
       {
          ui->gridboard->addWidget(settile(0),i,j);
       }
   }
   numsMatrix.resize(4);
   for (int i = 0; i < 4; i++)
       numsMatrix[i].resize(4);
   for (int i = 0; i < 4; i++)
       for (int j = 0; j < 4;j++)
           numsMatrix[i][j]=0;

   setinitialpos();

   ui->resetbutton->setEnabled(0);
   ui->gameoverlabel->hide();
   ui->Score_N->setText("0");
   ui->Tryagain->hide();
   ui->Tryagain->setEnabled(0);
   ui->newGame->hide();
   ui->winner->hide();
   ui->Quit->hide();
  // ui->newGame->setEnabled(0);
  // ui->Quit->setEnabled(0);
   ui->lastScore->hide();
   ui->youreScore->hide();
   ui->nicknamelabel->hide();
   ui->Nickname->hide();
   ui->submit->hide();
}


void NumsGame::on_resetbutton_clicked()
{
   reset();
}

void NumsGame::on_Tryagain_clicked()
{
    reset();
}

void NumsGame::on_Quit_clicked()
{
    close();
}

void NumsGame::on_newGame_clicked()
{
    reset();
}

void NumsGame::setdatabase(QString nickname,  int score)
{
    db =QSqlDatabase::addDatabase("QSQLITE");

    db.setDatabaseName("/home/ilyas/Desktop/scores_.sqlite");
    db.open();

      QSqlQuery query(db);


    QString create {"CREATE TABLE IF NOT EXISTS score (name VARCHAR(80), score int)"};
    if(!query.exec(create))
    {
        QMessageBox::critical(this,"info","could not create table");
    }

    QString insert {"INSERT INTO score values ('%1','%2')"};
    if(!query.exec(insert.arg(nickname).arg(score)))
    {
        QMessageBox::critical(this,"info","insert not create table");
    }
}

void NumsGame::on_submit_clicked()
{
    int c=0;
  //  setdatabase(ui->Nickname->text(),score);

    db =QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("/home/ilyas/Desktop/scores_.sqlite");
    db.open();

    QSqlQuery scoresnames("SELECT name from score ",db);

   //Load data from DB to each task_List
    while(scoresnames.next())
        scorenames.append(""+scoresnames.value(0).toString());

    for(auto e :scorenames)
    {
        if(ui->Nickname->text()==e)
        {
            c++;
        }
    }
//      while(c!=0)
//      {
//          ui->alreadyExist->show();
//      }
       ui->alreadyExist->hide();
      setdatabase(ui->Nickname->text(),score);
}
